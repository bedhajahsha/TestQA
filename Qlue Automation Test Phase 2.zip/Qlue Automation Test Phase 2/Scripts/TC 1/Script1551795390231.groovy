import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

WebUI.openBrowser('')

WebUI.navigateToUrl('https://qlue.co.id/')

WebUI.delay(15)

WebUI.verifyElementVisible(findTestObject('Qlue/homeimg'))

WebUI.verifyElementPresent(findTestObject('Object Repository/Qlue/Page_Home - Qlue/About Us'), 0)

//Untuk soal nomor 2 pada soal Automation Test object "projects, city partners, alliances" tidak ditemukan
//Saya menemukan object tersebut terdapat pada Website versi lama, berdasarkan data yang saya temukan dari
//https://web.archive.org/web/20180204171924/http://qlue.co.id/

WebUI.verifyElementPresent(findTestObject('Object Repository/Qlue/Page_Home - Qlue/Career'), 0)

//Untuk soal nomor 3 pada soal Automation Test object "project" tidak ditemukan sehingga saya tidak dapat click object tesebut
//akhirnya saya melakukan navigate to url dibawah ini

WebUI.navigateToUrl('https://qlue.co.id/projects')

result = WebUI.getText(findTestObject('Object Repository/Qlue/Page_Home - Qlue/Nama_jalan'))

WebUI.verifyElementText(findTestObject('Object Repository/Qlue/Page_Home - Qlue/Nama_jalan'), result)

WebUI.closeBrowser()
