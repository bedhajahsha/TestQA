<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Nama_jalan</name>
   <tag></tag>
   <elementGuidId>63febfe6-d80f-4b7b-8ac2-3ce35ca79f4f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact Us'])[1]/following::p[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//p[(text() = 'Jalan Pejaten Barat No. 13, RT.1/RW.8, Pejaten 

Barat, Pasar Minggu, Kota Jakarta Selatan, Daerah 

Khusus Ibukota Jakarta 12510' or . = 'Jalan Pejaten Barat No. 13, RT.1/RW.8, Pejaten 

Barat, Pasar Minggu, Kota Jakarta Selatan, Daerah 

Khusus Ibukota Jakarta 12510')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Jalan Pejaten Barat No. 13, RT.1/RW.8, Pejaten 

Barat, Pasar Minggu, Kota Jakarta Selatan, Daerah 

Khusus Ibukota Jakarta 12510</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;static-layout&quot;]/footer[1]/div[@class=&quot;inner container&quot;]/section[1]/div[@class=&quot;row wrap-foot&quot;]/div[@class=&quot;col-md-6&quot;]/div[@class=&quot;d-flex&quot;]/div[2]/p[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact Us'])[1]/following::p[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Find out more so you can be part of our story'])[1]/following::p[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='info@qlue.co.id'])[1]/preceding::p[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=concat('We', &quot;'&quot;, 're Hiring!')])[1]/preceding::p[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//section/div/div/div/div[2]/p</value>
   </webElementXpaths>
</WebElementEntity>
